# Social Media Campaign Performance Tracker
Auto-generated README for Task 2.