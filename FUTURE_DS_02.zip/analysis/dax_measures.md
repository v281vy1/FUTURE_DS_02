# DAX Measures
Total Impressions = SUM('cleaned-data-facebook'[impressions])