# Insights Summary
- Highest CTR Campaign: Example
- Platform Performance: FB > IG