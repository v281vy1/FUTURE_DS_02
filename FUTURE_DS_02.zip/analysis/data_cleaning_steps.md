# Data Cleaning Steps
- Removed duplicates
- Fixed data types
- Created KPIs